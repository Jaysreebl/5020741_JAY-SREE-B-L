package strategypattern;

public interface PaymentStrategy {
	void pay(double amount);

}
