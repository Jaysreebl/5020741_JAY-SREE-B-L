package factorymethod;

public interface ExcelDocument {
    void open();
    void save();
}