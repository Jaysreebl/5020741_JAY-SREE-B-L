package factorymethod;

public class Main {
    public static void main(String[] args) {
        // Creating Word document
        DocumentFactory wordFactory = new WordDocumentFactory();
        WordDocument wordDoc = (WordDocument) wordFactory.createDocument();
        wordDoc.open();
        wordDoc.save();

        // Creating PDF document
        DocumentFactory pdfFactory = new PdfDocumentFactory();
        PdfDocument pdfDoc = (PdfDocument) pdfFactory.createDocument();
        pdfDoc.open();
        pdfDoc.save();

        // Creating Excel document
        DocumentFactory excelFactory = new ExcelDocumentFactory();
        ExcelDocument excelDoc = (ExcelDocument) excelFactory.createDocument();
        excelDoc.open();
        excelDoc.save();
    }
}

