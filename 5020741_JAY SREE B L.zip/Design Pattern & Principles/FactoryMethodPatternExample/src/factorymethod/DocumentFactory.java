package factorymethod;

public abstract class DocumentFactory {
    public abstract Object createDocument();
}
