package factorymethod;

public interface WordDocument {
    void open();
    void save();
}