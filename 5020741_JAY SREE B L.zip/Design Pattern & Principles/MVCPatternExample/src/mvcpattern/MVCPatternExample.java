package mvcpattern;

public class MVCPatternExample {
    public static void main(String[] args) {
        // Fetch student record based on the student's roll no from the database
        Student model = retrieveStudentFromDatabase();

        // Create a view : to write student details on console
        StudentView view = new StudentView();

        StudentController controller = new StudentController(model, view);

        controller.updateView();

        // Update model data
        controller.setStudentName("John Doe");

        controller.updateView();
    }

    private static Student retrieveStudentFromDatabase() {
        return new Student("Robert", "10", "A");
    }
}

