package ems;

public class EmployeeManagementSystem {

    private Employee[] employees;
    private int count;

    public EmployeeManagementSystem(int capacity) {
        employees = new Employee[capacity];
        count = 0;
    }

    // Add a new employee
    public boolean addEmployee(Employee employee) {
        if (count >= employees.length) {
            System.out.println("Array is full. Cannot add employee.");
            return false;
        }
        employees[count++] = employee;
        return true;
    }

    // Search for an employee by employeeId
    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null;
    }

    // Traverse all employees
    public void traverseEmployees() {
        for (int i = 0; i < count; i++) {
            System.out.println(employees[i]);
        }
    }

    // Delete an employee by employeeId
    public boolean deleteEmployee(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                for (int j = i; j < count - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[--count] = null;
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(10);

        // Adding employees
        ems.addEmployee(new Employee(1, "Alice", "Manager", 75000));
        ems.addEmployee(new Employee(2, "Bob", "Developer", 60000));
        ems.addEmployee(new Employee(3, "Charlie", "Designer", 55000));

        // Traverse employees
        System.out.println("All Employees:");
        ems.traverseEmployees();

        // Search for an employee
        int searchId = 2;
        Employee emp = ems.searchEmployee(searchId);
        System.out.println("Employee with ID " + searchId + ": " + emp);

        // Delete an employee
        int deleteId = 1;
        boolean deleted = ems.deleteEmployee(deleteId);
        System.out.println("Employee with ID " + deleteId + " deleted: " + deleted);

        // Traverse employees after deletion
        System.out.println("All Employees after deletion:");
        ems.traverseEmployees();
    }
}
