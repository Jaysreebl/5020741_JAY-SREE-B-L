package sortingorders;

public class Main {

    public static void main(String[] args) {
        Order[] orders = {
            new Order("1", "Alice", 250.0),
            new Order("2", "Bob", 150.0),
            new Order("3", "Charlie", 350.0),
            new Order("4", "David", 200.0),
            new Order("5", "Eve", 300.0)
        };

        // Bubble Sort
        sortAndPrintOrders(orders, "Bubble Sort");

        // Reinitialize orders for Quick Sort
        orders = new Order[]{
            new Order("1", "Alice", 250.0),
            new Order("2", "Bob", 150.0),
            new Order("3", "Charlie", 350.0),
            new Order("4", "David", 200.0),
            new Order("5", "Eve", 300.0)
        };

        // Quick Sort
        sortAndPrintOrders(orders, "Quick Sort");
    }

    private static void sortAndPrintOrders(Order[] orders, String sortType) {
        System.out.println("Before " + sortType + ":");
        for (Order order : orders) {
            System.out.println(order.getOrderId() + ": " + order.getTotalPrice());
        }

        if ("Bubble Sort".equals(sortType)) {
            BubbleSort.bubbleSort(orders);
        } else if ("Quick Sort".equals(sortType)) {
            QuickSort.quickSort(orders, 0, orders.length - 1);
        }

        System.out.println("After " + sortType + ":");
        for (Order order : orders) {
            System.out.println(order.getOrderId() + ": " + order.getTotalPrice());
        }
    }
}
