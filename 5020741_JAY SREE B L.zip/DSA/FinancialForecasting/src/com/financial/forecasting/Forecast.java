package com.financial.forecasting;

public class Forecast {

    // Recursive method to calculate future value based on growth rate
    public double calculateFutureValue(double initialValue, double growthRate, int years) {
        if (years == 0) {
            return initialValue;
        }
        return (1 + growthRate) * calculateFutureValue(initialValue, growthRate, years - 1);
    }

    public static void main(String[] args) {
        Forecast forecast = new Forecast();

        double initialValue = 1000;  // Initial investment amount
        double growthRate = 0.05;    // Annual growth rate (5%)
        int years = 10;              // Number of years to forecast

        double futureValue = forecast.calculateFutureValue(initialValue, growthRate, years);
        System.out.println("The future value of the investment is: " + futureValue);
    }
}
